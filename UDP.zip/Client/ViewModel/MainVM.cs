﻿using Common;
using System;
using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Data;

namespace Client.ViewModel
{
    public class MainVM : Notifiable
    {
        Socket tradeClient, newsClient;
        public static Socket orderClient;
        EndPoint tradePoint, newsPoint, orderPoint;

        CancellationTokenSource receiveSource;
        public Command SubmitOrder { get; set; }
        public Command Check { get; set; }
        public Command Reset { get; set; }

        public ObservableCollection<string> Orders { get; set; }
        public ObservableCollection<string> News { get; set; }
        public string Sent { get; set; }
        string IP;
        int count;
        public int ReceiveCount { get; set; }
        ConcurrentQueue<byte[]> orderQueue;

        int recCount = 0;
        public MainVM()
        {
            Orders = new ObservableCollection<string>();
            News = new ObservableCollection<string>();
            BindingOperations.EnableCollectionSynchronization(Orders, Orders);
            BindingOperations.EnableCollectionSynchronization(News, News);
            orderQueue = new ConcurrentQueue<byte[]>();

            tradePoint = new IPEndPoint(IPAddress.Any, Constants.TRADE_PORT);
            tradeClient = new Socket(SocketType.Dgram, ProtocolType.Udp);
            tradeClient.Bind(tradePoint);

            newsPoint = new IPEndPoint(IPAddress.Any, Constants.NEWS_PORT);
            newsClient = new Socket(SocketType.Dgram, ProtocolType.Udp);
            newsClient.Bind(newsPoint);

            orderPoint = new IPEndPoint(IPAddress.Parse(Constants.ORDER_IP), Constants.ORDER_PORT);
            orderClient = new Socket(SocketType.Dgram, ProtocolType.Udp);

    receiveSource = new CancellationTokenSource();
    Task.Run(receiveOrder, receiveSource.Token);
    Task.Run(processOrder, receiveSource.Token);
            Task.Run(receiveNews, receiveSource.Token);
            SubmitOrder = new Command(submitOrder, (o) => true);
            Check = new Command(check, (o) => true);
            Reset = new Command(reset, (o) => true);

            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    IP= ip.ToString();
                }
            }
        }

        void check(object o)
        {
            ReceiveCount = recCount;
            OnPropertyChanged(nameof(ReceiveCount));
        }
        void receiveNews()
        {
            var buffer = new byte[Constants.NEWS_SIZE];
            while (!receiveSource.IsCancellationRequested)
            {
                newsClient.Receive(buffer);
                News.Add(Encoding.UTF8.GetString(buffer));
                Array.Clear(buffer, 0, buffer.Length);
            }
        }
        void reset(object o)
        {
            ReceiveCount = recCount = 0;
            OnPropertyChanged(nameof(ReceiveCount));
        }

        void receiveOrder()
        {
            var buffer = new byte[Constants.ORDER_SIZE];
            while (!receiveSource.IsCancellationRequested)
            {
                tradeClient.Receive(buffer);
                recCount++;
                orderQueue.Enqueue(buffer.ToArray());
            }
        }
       
        void processOrder()
        {
            while (!receiveSource.IsCancellationRequested)
            {
                if (orderQueue.Count > 0)
                {
                    byte[] buffer;
                    while (!orderQueue.TryDequeue(out buffer)) { }
                    Orders.Add(Encoding.UTF8.GetString(buffer));
                    count++;
                }
            }
        }

        void submitOrder(object o)
        {
            count = 1;
            Orders.Clear();
            News.Clear();
            int no = 1;

            Task.Run(() =>
            {
                for (int i = 0; i < 25000; i++)
                {
                    var buffer = new byte[Constants.ORDER_SIZE];
                    var message = Encoding.UTF8.GetBytes("Order " + no++);
                    Buffer.BlockCopy(message, 0, buffer, 0, message.Length);
                    orderClient.SendTo(buffer, orderPoint);
                    Task.Delay(1);
                }
            }).Wait();
            Sent = IP + " submission Complete";
            OnPropertyChanged(nameof(Sent));
        }
    }
}
