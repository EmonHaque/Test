﻿using Common;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace Server
{
    public class ViewModel : Notifiable
    {
        Socket broadcaster, receiver;
        EndPoint broadcastPoint, receivePoint; 
        bool isListening;
        int receivedPacket = 0;
        int broadcastedPacket = 0;

        public Command Start { get; set; }
        public Command Stop { get; set; }
        public Command Check { get; set; }
        public Command Reset { get; set; }

        CancellationTokenSource receiveSource;
        ConcurrentQueue<byte[]> orderQueue;

        public int ReceivedPacket { get; set; }
        public int BroadcastedPacket { get; set; }

        public ViewModel()
        {
            orderQueue = new ConcurrentQueue<byte[]>();
            Start = new Command(start, (o) => !isListening);
            Stop = new Command(stop, (o) => isListening);
            Check = new Command(check, (o) => true);
            Reset = new Command(reset, (o) => true);
        }

        void start(object o)
        {
            receivePoint = new IPEndPoint(IPAddress.Parse(Constants.ORDER_IP), Constants.ORDER_PORT);
            receiver = new Socket(SocketType.Dgram, ProtocolType.Udp);
            receiver.Bind(receivePoint);

            broadcastPoint = new IPEndPoint(IPAddress.Parse(Constants.TRADE_NET), Constants.TRADE_PORT);
            broadcaster = new Socket(SocketType.Dgram, ProtocolType.Udp) { EnableBroadcast = true };
            
            isListening = true;
            receiveSource = new CancellationTokenSource();
            Task.Run(receiveOrder, receiveSource.Token);
            Task.Run(processOrder);
        }
        
        void receiveOrder()
        {
            var buffer = new byte[Constants.ORDER_SIZE];
            while (!receiveSource.IsCancellationRequested)
            {
                receiver.Receive(buffer);
                orderQueue.Enqueue(buffer.ToArray());
                Array.Clear(buffer, 0, buffer.Length);
                receivedPacket++;
            }
        }

        void processOrder()
        {
            while (true)
            {
                if (orderQueue.Count > 0)
                {
                    byte[] buffer;
                    while (!orderQueue.TryDequeue(out buffer)) { }
                    broadcaster.SendTo(buffer, broadcastPoint);
                    broadcastedPacket++;
                    Thread.Sleep(1);
                }
                else Thread.Sleep(10);
            }
        }

        void check(object o)
        {
            ReceivedPacket = receivedPacket;
            BroadcastedPacket = broadcastedPacket;
            OnPropertyChanged(nameof(ReceivedPacket));
            OnPropertyChanged(nameof(BroadcastedPacket));
        }

        void reset(object o)
        {
            receivedPacket = broadcastedPacket = 0;
            ReceivedPacket = receivedPacket;
            BroadcastedPacket = broadcastedPacket;
            OnPropertyChanged(nameof(ReceivedPacket));
            OnPropertyChanged(nameof(BroadcastedPacket));
        }

        void stop(object o)
        {
            receiveSource.Cancel();
            receiveSource.Dispose();
            isListening = false;
            broadcaster.Close();
            broadcaster.Dispose();
        }
    }
}
