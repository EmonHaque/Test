﻿using Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Press
{
    public class ViewModel : Notifiable
    {
        Socket broadcaster;
        EndPoint newsPoint;

        public string Message { get; set; }
        public ObservableCollection<string> News { get; set; }

        public Command Add { get; set; }
        public Command BroadCast { get; set; }

        public ViewModel()
        {
            News = new ObservableCollection<string>();
            newsPoint = new IPEndPoint(IPAddress.Parse(Constants.NEWS_NET), Constants.NEWS_PORT);
            broadcaster = new Socket(SocketType.Dgram, ProtocolType.Udp) { EnableBroadcast = true };
            Add = new Command(add, isMessageValid);
            BroadCast = new Command(broadcast, (o) => News.Count > 0);
        }

        void add(object o)
        {
            News.Add(Message);
            Message = string.Empty;
            OnPropertyChanged(nameof(Message));
        }

        bool isMessageValid(object o)
        {
            if (string.IsNullOrWhiteSpace(Message)) return false;
            return Encoding.UTF8.GetBytes(Message).Length <= Constants.NEWS_SIZE;

        }

        void broadcast(object o)
        {
            foreach (var @new in News)
            {
                var buffer = Encoding.UTF8.GetBytes(@new);
                broadcaster.SendTo(buffer, newsPoint);
                Thread.Sleep(50);
            }
            News.Clear();
        }
    }
}
