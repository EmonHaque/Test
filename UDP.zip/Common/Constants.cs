﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    public class Constants
    {
        public const string NEWS_NET = "192.168.0.255";
        public const string TRADE_NET = "192.168.0.255";
        public const string ORDER_IP = "192.168.0.101";

        public const int ORDER_SIZE = 88;
        public const int NEWS_SIZE = 1024;

        public const int TRADE_PORT = 3000;
        public const int NEWS_PORT = 4000;
        public const int ORDER_PORT = 5000;
    }
}
