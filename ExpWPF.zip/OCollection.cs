﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Threading;
using System.Windows.Data;

namespace RentManager.Common
{
    public class OCollection<T> : ObservableCollection<T>
    {
        //SynchronizationContext is not Serializable!
        SynchronizationContext context = SynchronizationContext.Current;
        readonly object _lock = new object();
        public OCollection() { BindingOperations.EnableCollectionSynchronization(this, _lock); }
        public OCollection(IEnumerable<T> list) : base(list) { BindingOperations.EnableCollectionSynchronization(this, _lock); }

        void RaiseCollectionChanged(object param) => base.OnCollectionChanged((NotifyCollectionChangedEventArgs)param);
        void RaisePropertyChanged(object param) => base.OnPropertyChanged((PropertyChangedEventArgs)param);

        protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            if (SynchronizationContext.Current == context) RaiseCollectionChanged(e);
            else context.Send(RaiseCollectionChanged, e);
        }

        protected override void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (SynchronizationContext.Current == context) RaisePropertyChanged(e);
            else context.Send(RaisePropertyChanged, e);
        }

        public void InsertRange(IEnumerable<T> items)
        {
            CheckReentrancy();
            foreach (var item in items) Items.Add(item);
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }

        public void RaiseCollectionChanged()
        {
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }
    }
}
