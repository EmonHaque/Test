﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Data;

namespace ExpWPF
{
    public class MainVM : Notifiable
    {
        Collection<Item> items;
        public ICollectionView Items { get; set; }

        public Command Add { get; set; }
        public Command Remove { get; set; }
        public Command Edit { get; set; }
        public Command Replace { get; set; }
        public Command Move { get; set; }
        public Command Clear { get; set; }
        int count;

        public MainVM()
        {
            items = new Collection<Item>();
            Items = CollectionViewSource.GetDefaultView(items);
            Add = new Command(add, (o) => true);
            Remove = new Command(remove, (o) => true);
            Edit = new Command(edit, (o) => true);
            Replace = new Command(replace, (o) => true);
            Move = new Command(move, (o) => true);
            Clear = new Command(clear, (o) => true);
        }
        void edit(object o)
        {
            Item oldItem = null;
            Task.Run(() =>
            {
                oldItem = o as Item;
                oldItem.Name = "Edited " + oldItem.Id;
            }).Wait();
            oldItem.OnPropertyChanged(nameof(oldItem.Name));
        }

        void add(object o)
        {
            var index = items.Count;
            for (int i = 0; i < 3; i++)
            {
                items.Add(new Item()
                {
                    Id = ++count,
                    Name = "Item No. " + count
                });
            }
            var newItems = items.GetRange(index, items.Count - index);
            items.OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, newItems, index));
        }

        void remove(object o)
        {
            var oldItems = new List<object>(o as IEnumerable<object>);
            var indexOfFirstItem = items.IndexOf(oldItems.First() as Item);
            foreach (var item in oldItems)
            {
                items.Remove(item as Item);
            }
            items.OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, oldItems, indexOfFirstItem));
        }

        void replace(object o)
        {
            var oldItems = new List<object>(o as IEnumerable<object>);
            var newItems = new List<Item>();
            var indexOfFirstItem = items.IndexOf(oldItems.First() as Item); 
            foreach (var item in oldItems)
            {
                var old = item as Item;
                var @new = new Item()
                {
                    Id = old.Id,
                    Name = "Replaced " + old.Id
                };
                items[items.IndexOf(old)] = @new;
                newItems.Add(@new);
            }
            items.OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Replace, newItems, oldItems, indexOfFirstItem));
        }

        void move(object o)
        {
            Item item = null;
            int oldIndex, newIndex;
            oldIndex = newIndex = 0;
            Task.Run(() =>
            {
                item = o as Item;
                oldIndex = items.IndexOf(item);
                newIndex = 0;
                items.Insert(newIndex, item);
            }).Wait();
            items.OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Move, item, newIndex, oldIndex));
        }

        void clear(object o)
        {
            Task.Run(items.Clear).Wait();
            items.OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }
    }

    public class Item : Notifiable
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
