﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace ExpWPF
{
    public class Collection<T> : IList<T>, INotifyCollectionChanged
    {
        readonly List<T> list;

        #region constructiors
        public Collection() => list = new List<T>();
        public Collection(IEnumerable<T> enumerable) => list = enumerable.ToList();
        public Collection(List<T> list) => this.list = list;
        #endregion

        #region IList<T> implementation
        public T this[int index] { get => list[index]; set => list[index] = value; }
        public bool IsReadOnly => true;
        public int Count => list.Count;
        public void Add(T item) => list.Add(item);
        public bool Remove(T item) => list.Remove(item);
        public void Clear() => list.Clear();
        public bool Contains(T item) => list.Contains(item);
        public int IndexOf(T item) => list.IndexOf(item);
        public void Insert(int index, T item) => list.Insert(index, item);
        public void RemoveAt(int index) => list.RemoveAt(index);
        public void CopyTo(T[] array, int arrayIndex) => list.CopyTo(array, arrayIndex);
        public IEnumerator<T> GetEnumerator() => list.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        #endregion

        #region List<T>
        public void AddRange(IEnumerable<T> source) => list.AddRange(source);
        public void InsertRange(int index, IEnumerable<T> source) => list.InsertRange(index, source);
        public void RmoveRange(int index, int count) => list.RemoveRange(index, count);
        public List<T> GetRange(int index, int count) => list.GetRange(index, count);
        #endregion

        #region INotifyCollectionChanged implementation
        public event NotifyCollectionChangedEventHandler CollectionChanged;
        public void OnCollectionChanged(NotifyCollectionChangedEventArgs e) => CollectionChanged?.Invoke(this, e);
        #endregion
    }
}
