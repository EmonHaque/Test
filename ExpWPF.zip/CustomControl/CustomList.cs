﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExpWPF.CustomControl
{
    public class CustomList : ListBox
    {
        static CustomList()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CustomList), new FrameworkPropertyMetadata(typeof(CustomList)));
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            View = Items;
        }

        public ItemCollection View
        {
            get { return (ItemCollection)GetValue(ViewProperty); }
            set { SetValue(ViewProperty, value); }
        }

        // Using a DependencyProperty as the backing store for View.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ViewProperty =
            DependencyProperty.Register("View", typeof(ItemCollection), typeof(CustomList), new PropertyMetadata(null));

    }
}
