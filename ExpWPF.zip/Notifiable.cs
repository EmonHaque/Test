﻿using System;
using System.Collections.Specialized;
using System.ComponentModel;

namespace ExpWPF
{
    public abstract class Notifiable : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

}
